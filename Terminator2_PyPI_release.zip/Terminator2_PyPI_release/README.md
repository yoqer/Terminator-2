# Terminator 2

**Terminator 2** es un motor de inferencia y servicios multimodales preparado para **producción local**, **hosting estándar** y **publicación en PyPI**. El paquete mantiene el módulo interno `terminatori` por compatibilidad, pero la identidad pública de esta versión es **Terminator 2**, con arquitectura de proveedores configurable desde backend, API FastAPI/ASGI, integración de voz ampliada y una capa de **corrección de sesgos por *steering*** inspirada en **TenMiNaTor**.

## Qué incluye esta versión

Esta edición deja atrás la base mínima inicial y consolida una estructura lista para despliegue. El sistema expone inferencia textual, sesiones, A2A, MCP, voz TTS/STT, skills, avatar, vídeo, robótica simulada y una interfaz web mínima. Además, incorpora una capa homogénea para seleccionar proveedores por configuración, con soporte tanto para ejecución real por API como para respuesta de respaldo local cuando no hay credenciales configuradas.

| Área | Estado en Terminator 2 | Observación |
|---|---|---|
| API HTTP | Completa | FastAPI + OpenAPI + ASGI |
| Compatibilidad OpenAI | Disponible | `/v1/chat/completions` |
| Proveedores LLM por backend | Disponible | OpenAI, xAI/Grok, Anthropic, DeepSeek, Mistral, OpenRouter, Ollama, llama.cpp |
| Selección de modelo | Disponible | Por configuración o en caliente |
| TTS/STT | Disponible | OpenAI, ElevenLabs, Grok, Kokoro, Coqui, Silero, gTTS, Whisper, Deepgram |
| Corrección de sesgos | Disponible | *Steering* configurable con TenMiNaTor |
| Skills | Disponible | Aureolas y registro extensible |
| Memoria | Disponible | SQLite ligera |
| Despliegue local | Disponible | `start_local.sh` |
| Despliegue producción | Disponible | `start_production.sh`, `Dockerfile`, `Procfile` |
| PyPI | Preparado | `wheel` y `sdist` generados |

## Estructura principal

El proyecto se distribuye como paquete Python con una organización clara de capas. La lógica central reside en `terminatori/core`, mientras que la exposición HTTP se concentra en `terminatori/api`, y los módulos auxiliares se reparten por dominio funcional.

| Ruta | Propósito |
|---|---|
| `terminatori/core/config.py` | Configuración central de Terminator 2 |
| `terminatori/core/backends.py` | Registro y backends de proveedores LLM |
| `terminatori/core/engine.py` | Motor de inferencia, sesiones y *steering* |
| `terminatori/api/app.py` | API FastAPI y punto de entrada ASGI |
| `terminatori/voice/voice_manager.py` | Gestión TTS/STT con selección de proveedor |
| `terminatori/skills/aureolas.py` | Skills internas y extensibilidad |
| `terminatori/memory/memory_manager.py` | Persistencia ligera |
| `terminatori/avatar/` | Gestión básica de avatares |
| `terminatori/video/` | Gestión básica de vídeo |
| `terminatori/robotics/` | Robótica simulada y comandos |
| `terminatori/panel/static/` | Panel web mínimo |
| `tests/` | Suite de pruebas |
| `dist/` | Artefactos listos para PyPI |

## Instalación rápida

Puedes instalar el paquete desde código fuente o usar directamente los artefactos generados para PyPI. En desarrollo local, el flujo más cómodo consiste en clonar, configurar el entorno y arrancar el servicio.

```bash
git clone https://github.com/yoqer/TerminatorI.git
cd TerminatorI
cp .env.example .env
chmod +x start_local.sh
./start_local.sh
```

Si deseas instalar el paquete como librería local usando el artefacto generado:

```bash
pip install dist/terminator2-2.0.0-py3-none-any.whl
```

## Uso básico como librería

La API pública de esta versión expone `Terminator2` y `Terminator2Config` como nombres principales. Se mantienen alias para `TerminatorI` por compatibilidad hacia atrás.

```python
import asyncio
from terminatori import Terminator2, Terminator2Config

async def main():
    cfg = Terminator2Config(model="openai/gpt-4o-mini")
    engine = Terminator2(cfg)
    await engine.start()
    try:
        result = await engine.infer("Hola, Terminator 2")
        print(result.text)
        print(result.metadata)
    finally:
        await engine.stop()

asyncio.run(main())
```

## Proveedores LLM

El motor permite seleccionar el proveedor a través del identificador de modelo con el formato `proveedor/modelo`. Si no hay credenciales disponibles, el backend devuelve una respuesta de respaldo local para no bloquear pruebas, cableado ni arranque del servicio.

| Proveedor | Formato de modelo | Tipo de backend |
|---|---|---|
| OpenAI | `openai/gpt-4o-mini` | API compatible OpenAI |
| xAI / Grok | `grok/grok-3` | API compatible OpenAI |
| Anthropic | `anthropic/claude-3-5-sonnet-latest` | API Anthropic |
| DeepSeek | `deepseek/deepseek-chat` | API compatible OpenAI |
| Mistral | `mistral/mistral-large-latest` | API compatible OpenAI |
| OpenRouter | `openrouter/openai/gpt-4o-mini` | API compatible OpenAI |
| Ollama | `ollama/llama3.2` | API local Ollama |
| llama.cpp | `llamacpp/ruta/al/modelo.gguf` | Backend local |

## Voz: Coqui, Silero, Kokoro y proveedores API

La pila de voz se amplía de forma importante en esta versión. **Coqui** queda como opción preferente cuando se prioriza cobertura multilingüe, incluyendo escenarios como **árabe**, clonación de voz y despliegues más expresivos. **Silero** queda integrado como alternativa ligera y rápida para CPU o dispositivos pequeños. **Kokoro** sigue soportado como opción local adicional. Junto a ello, el sistema conserva proveedores por API como OpenAI, ElevenLabs y Grok, además de gTTS para casos básicos.

| Proveedor | Tipo | Enfoque recomendado |
|---|---|---|
| Coqui | TTS / STT local | Máxima cobertura multilingüe, incluyendo árabe |
| Silero | TTS ligero / STT reservado | CPU, dispositivos pequeños y respuesta rápida |
| Kokoro | TTS local | Opción local sencilla y ya conocida en el ecosistema |
| OpenAI | TTS / STT API | Integración directa en nube |
| ElevenLabs | TTS API | Voz de alta calidad |
| Grok | TTS API | Audio vía xAI |
| Whisper | STT local o API | Transcripción general |
| Deepgram | STT API | Transcripción externa |
| gTTS | TTS básico | Casos sencillos y rápidos |

Los endpoints clave para voz son `/api/tts`, `/api/stt`, `/api/v1/voice/synthesize`, `/api/v1/voice/transcribe` y `/api/voice/providers`.

## Corrección de sesgos por steering con TenMiNaTor

Terminator 2 incorpora una capa configurable de **corrección de sesgos** orientada a *steering*. Esta capa permite añadir directrices de neutralidad e inclusión sobre el prompt del sistema y, además, aplicar un postprocesado final sobre la respuesta generada. La configuración contempla intensidad, modo de trabajo y una bandera para aproximación a capas intermedias.

| Variable | Función |
|---|---|
| `TERMINATOR2_BIAS_STEERING` | Activa o desactiva la corrección |
| `TERMINATOR2_BIAS_STEERING_MODE` | Define el modo, por ejemplo `final_inference` |
| `TERMINATOR2_BIAS_STEERING_STRENGTH` | Intensidad de la corrección |
| `TERMINATOR2_BIAS_STEERING_LAYERS` | Extiende el enfoque hacia capas intermedias simuladas |
| `TERMINATOR2_BIAS_STEERING_KEYWORDS` | Palabras guía de neutralidad e inclusión |

## Endpoints principales

La API incluye compatibilidad moderna para integración con clientes externos, automatizaciones y despliegues propios.

| Grupo | Rutas principales |
|---|---|
| Salud | `/health`, `/status` |
| Chat | `/v1/chat/completions` |
| Inferencia | `/api/infer`, `/api/v1/infer`, `/api/stream`, `/api/v1/stream` |
| Modelos | `/api/models`, `/api/model/switch`, `/api/providers` |
| Sesiones | `/api/sessions`, `/api/sessions/{session_id}` |
| Voz | `/api/tts`, `/api/stt`, `/api/v1/voice/synthesize`, `/api/v1/voice/transcribe`, `/api/voice/providers` |
| Skills | `/api/skills`, `/api/skills/execute` |
| Avatar | `/api/avatar/generate`, `/api/avatar/models` |
| Vídeo | `/api/video/generate` |
| Robótica | `/api/robotics/command` |
| A2A | `/a2a/agent-card`, `/a2a/message` |
| MCP | `/mcp/tools`, `/mcp/call` |
| Panel | `/panel` |

## Despliegue

Terminator 2 se ha preparado para escenarios reales de ejecución. Puede lanzarse localmente, en un VPS, dentro de Docker o sobre plataformas que acepten un proceso Python web estándar.

| Archivo | Uso |
|---|---|
| `start_local.sh` | Desarrollo local |
| `start_production.sh` | Arranque simple en servidor |
| `Dockerfile` | Contenedor estándar |
| `Procfile` | Plataformas tipo Render o Railway |
| `requirements.txt` | Instalación manual de dependencias |
| `.env.example` | Configuración de entorno |

## Estado de validación

La base ha sido validada con la suite actual del proyecto y con construcción correcta de artefactos para distribución.

| Validación | Estado |
|---|---|
| Suite pytest | 39/39 pruebas superadas |
| Compilación Python | Correcta |
| `wheel` | Generado |
| `sdist` | Generado |
| Comprobación de metadatos | Correcta |

## Publicación en PyPI

Una vez revisados los secretos y la cuenta de publicación, el flujo estándar sería el siguiente.

```bash
python3 -m build
twine check dist/*
twine upload dist/*
```

## Compatibilidad y continuidad

El paquete mantiene compatibilidad parcial con la nomenclatura antigua mediante alias internos, pero esta versión debe considerarse la base de **Terminator 2** y el punto de partida recomendado para integraciones posteriores con **TenMiNaTor III / Ten III**.

## Licencia

El proyecto se distribuye bajo licencia **MIT**.

## Autoría

Repositorio original: **yoqer**.  
Reestructuración técnica, endurecimiento productivo y documentación final: **Manus AI**.
