"""Backends productivos y registrables para Terminator 2."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, AsyncIterator, Dict, List, Optional


@dataclass
class ProviderSpec:
    id: str
    label: str
    backend_type: str
    base_url: Optional[str] = None
    api_key: Optional[str] = None
    capabilities: List[str] = field(default_factory=lambda: ["chat", "stream"])


class BackendError(RuntimeError):
    pass


class _BaseBackend:
    def __init__(self, spec: ProviderSpec, model: str, timeout: float = 60.0, **kwargs):
        self.spec = spec
        self.model = model
        self.timeout = timeout
        self.kwargs = kwargs

    async def close(self) -> None:
        return None

    async def complete(
        self,
        messages: List[Dict[str, Any]],
        temperature: float = 0.7,
        max_tokens: int = 1024,
        tools: Optional[List[Dict[str, Any]]] = None,
    ) -> Dict[str, Any]:
        last_user = next((m.get("content", "") for m in reversed(messages) if m.get("role") == "user"), "")
        text = (
            f"Respuesta local de respaldo de {self.spec.id} para el modelo '{self.model}'. "
            f"Entrada recibida: {last_user}"
        )
        return {
            "text": text,
            "tokens_used": min(max(len(text.split()), 1), max_tokens),
            "metadata": {
                "provider": self.spec.id,
                "backend_type": self.spec.backend_type,
                "fallback": True,
                "tools": bool(tools),
            },
        }

    async def stream(
        self,
        messages: List[Dict[str, Any]],
        temperature: float = 0.7,
        max_tokens: int = 1024,
        tools: Optional[List[Dict[str, Any]]] = None,
    ) -> AsyncIterator[str]:
        response = await self.complete(messages=messages, temperature=temperature, max_tokens=max_tokens, tools=tools)
        for token in response["text"].split():
            yield token + " "


class OpenAICompatibleBackend(_BaseBackend):
    async def complete(
        self,
        messages: List[Dict[str, Any]],
        temperature: float = 0.7,
        max_tokens: int = 1024,
        tools: Optional[List[Dict[str, Any]]] = None,
    ) -> Dict[str, Any]:
        if not self.spec.api_key or not self.spec.base_url:
            return await super().complete(messages=messages, temperature=temperature, max_tokens=max_tokens, tools=tools)

        import httpx

        url = self.spec.base_url.rstrip("/") + "/chat/completions"
        payload: Dict[str, Any] = {
            "model": self.model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": False,
        }
        if tools:
            payload["tools"] = tools

        headers = {
            "Authorization": f"Bearer {self.spec.api_key}",
            "Content-Type": "application/json",
        }
        if self.spec.id in {"openrouter"}:
            headers["HTTP-Referer"] = "https://github.com/yoqer/TerminatorI"
            headers["X-Title"] = "Terminator 2"

        async with httpx.AsyncClient(timeout=self.timeout) as client:
            resp = await client.post(url, headers=headers, json=payload)
            resp.raise_for_status()
            data = resp.json()

        choice = (data.get("choices") or [{}])[0]
        message = choice.get("message") or {}
        text = message.get("content", "")
        usage = data.get("usage") or {}
        return {
            "text": text,
            "tokens_used": usage.get("total_tokens") or usage.get("completion_tokens") or min(max(len(text.split()), 1), max_tokens),
            "metadata": {
                "provider": self.spec.id,
                "backend_type": self.spec.backend_type,
                "model": data.get("model", self.model),
                "finish_reason": choice.get("finish_reason"),
            },
        }


class OllamaBackend(_BaseBackend):
    async def complete(
        self,
        messages: List[Dict[str, Any]],
        temperature: float = 0.7,
        max_tokens: int = 1024,
        tools: Optional[List[Dict[str, Any]]] = None,
    ) -> Dict[str, Any]:
        if not self.spec.base_url:
            return await super().complete(messages=messages, temperature=temperature, max_tokens=max_tokens, tools=tools)

        import httpx

        payload = {
            "model": self.model,
            "messages": messages,
            "stream": False,
            "options": {"temperature": temperature, "num_predict": max_tokens},
        }
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            resp = await client.post(self.spec.base_url.rstrip("/") + "/api/chat", json=payload)
            resp.raise_for_status()
            data = resp.json()

        message = data.get("message") or {}
        text = message.get("content", "")
        return {
            "text": text,
            "tokens_used": data.get("eval_count") or min(max(len(text.split()), 1), max_tokens),
            "metadata": {
                "provider": self.spec.id,
                "backend_type": self.spec.backend_type,
                "total_duration": data.get("total_duration"),
                "load_duration": data.get("load_duration"),
            },
        }


class AnthropicBackend(_BaseBackend):
    async def complete(
        self,
        messages: List[Dict[str, Any]],
        temperature: float = 0.7,
        max_tokens: int = 1024,
        tools: Optional[List[Dict[str, Any]]] = None,
    ) -> Dict[str, Any]:
        if not self.spec.api_key or not self.spec.base_url:
            return await super().complete(messages=messages, temperature=temperature, max_tokens=max_tokens, tools=tools)

        import httpx

        system_parts = [m.get("content", "") for m in messages if m.get("role") == "system"]
        transformed_messages = [m for m in messages if m.get("role") in {"user", "assistant"}]
        payload = {
            "model": self.model,
            "messages": transformed_messages,
            "max_tokens": max_tokens,
            "temperature": temperature,
        }
        if system_parts:
            payload["system"] = "\n".join(system_parts)

        headers = {
            "x-api-key": self.spec.api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        }
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            resp = await client.post(self.spec.base_url.rstrip("/") + "/messages", headers=headers, json=payload)
            resp.raise_for_status()
            data = resp.json()

        content = data.get("content") or []
        text_parts = [item.get("text", "") for item in content if item.get("type") == "text"]
        text = "\n".join(part for part in text_parts if part)
        usage = data.get("usage") or {}
        return {
            "text": text,
            "tokens_used": usage.get("output_tokens") or min(max(len(text.split()), 1), max_tokens),
            "metadata": {
                "provider": self.spec.id,
                "backend_type": self.spec.backend_type,
                "stop_reason": data.get("stop_reason"),
            },
        }


class LlamaCppBackend(_BaseBackend):
    def __init__(self, spec: ProviderSpec, model: str, timeout: float = 60.0, n_ctx: int = 4096, n_gpu_layers: int = 0, **kwargs):
        super().__init__(spec=spec, model=model, timeout=timeout, n_ctx=n_ctx, n_gpu_layers=n_gpu_layers, **kwargs)
        self.n_ctx = n_ctx
        self.n_gpu_layers = n_gpu_layers

    async def complete(
        self,
        messages: List[Dict[str, Any]],
        temperature: float = 0.7,
        max_tokens: int = 1024,
        tools: Optional[List[Dict[str, Any]]] = None,
    ) -> Dict[str, Any]:
        try:
            from llama_cpp import Llama
        except ImportError:
            return await super().complete(messages=messages, temperature=temperature, max_tokens=max_tokens, tools=tools)

        prompt = "\n".join(f"{m.get('role', 'user')}: {m.get('content', '')}" for m in messages)
        llm = Llama(model_path=self.model, n_ctx=self.n_ctx, n_gpu_layers=self.n_gpu_layers, verbose=False)
        result = llm.create_completion(prompt=prompt + "\nassistant:", max_tokens=max_tokens, temperature=temperature)
        choice = (result.get("choices") or [{}])[0]
        text = choice.get("text", "").strip()
        usage = result.get("usage") or {}
        return {
            "text": text,
            "tokens_used": usage.get("total_tokens") or min(max(len(text.split()), 1), max_tokens),
            "metadata": {
                "provider": self.spec.id,
                "backend_type": self.spec.backend_type,
                "local_model_path": self.model,
            },
        }


def build_provider_registry(config) -> Dict[str, ProviderSpec]:
    creds = config.provider_credentials
    return {
        "openai": ProviderSpec("openai", "OpenAI", "openai-compatible", creds["openai"]["base_url"], creds["openai"]["api_key"]),
        "openai-compatible": ProviderSpec("openai-compatible", "OpenAI Compatible", "openai-compatible", creds["openai-compatible"]["base_url"], creds["openai-compatible"]["api_key"]),
        "grok": ProviderSpec("grok", "Grok/xAI", "openai-compatible", creds["grok"]["base_url"], creds["grok"]["api_key"]),
        "xai": ProviderSpec("xai", "xAI", "openai-compatible", creds["xai"]["base_url"], creds["xai"]["api_key"]),
        "deepseek": ProviderSpec("deepseek", "DeepSeek", "openai-compatible", creds["deepseek"]["base_url"], creds["deepseek"]["api_key"]),
        "mistral": ProviderSpec("mistral", "Mistral", "openai-compatible", creds["mistral"]["base_url"], creds["mistral"]["api_key"]),
        "openrouter": ProviderSpec("openrouter", "OpenRouter", "openai-compatible", creds["openrouter"]["base_url"], creds["openrouter"]["api_key"]),
        "anthropic": ProviderSpec("anthropic", "Anthropic", "anthropic", creds["anthropic"]["base_url"], creds["anthropic"]["api_key"]),
        "ollama": ProviderSpec("ollama", "Ollama", "ollama", creds["ollama"]["base_url"], None),
        "llamacpp": ProviderSpec("llamacpp", "llama.cpp", "llamacpp", None, None),
    }


def create_backend(provider_id: str, model: str, config):
    registry = build_provider_registry(config)
    if provider_id not in registry:
        raise BackendError(f"Unsupported provider: {provider_id}")

    spec = registry[provider_id]
    if spec.backend_type == "openai-compatible":
        return OpenAICompatibleBackend(spec=spec, model=model, timeout=config.provider_timeout)
    if spec.backend_type == "anthropic":
        return AnthropicBackend(spec=spec, model=model, timeout=config.provider_timeout)
    if spec.backend_type == "ollama":
        return OllamaBackend(spec=spec, model=model, timeout=config.provider_timeout)
    if spec.backend_type == "llamacpp":
        return LlamaCppBackend(
            spec=spec,
            model=model,
            timeout=config.provider_timeout,
            n_ctx=config.context_length,
            n_gpu_layers=config.gpu_layers,
        )
    raise BackendError(f"Backend type not implemented: {spec.backend_type}")


def list_builtin_models(config) -> List[Dict[str, Any]]:
    registry = build_provider_registry(config)
    catalogue = {
        "openai": ["gpt-4o", "gpt-4o-mini"],
        "grok": ["grok-2", "grok-3"],
        "anthropic": ["claude-3-5-sonnet-latest"],
        "deepseek": ["deepseek-chat"],
        "mistral": ["mistral-large-latest"],
        "openrouter": ["openai/gpt-4o-mini", "deepseek/deepseek-chat"],
    }
    models: List[Dict[str, Any]] = []
    for provider_id, items in catalogue.items():
        spec = registry[provider_id]
        for item in items:
            models.append(
                {
                    "id": f"{provider_id}/{item}",
                    "name": item,
                    "provider": provider_id,
                    "configured": bool(spec.api_key) if provider_id != "ollama" else True,
                }
            )
    models.append({"id": "ollama/llama3.2", "name": "llama3.2", "provider": "ollama", "configured": True})
    return models
