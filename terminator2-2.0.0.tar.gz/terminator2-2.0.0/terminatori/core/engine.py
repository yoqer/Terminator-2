"""Motor principal de Terminator 2."""

from __future__ import annotations

import logging
import time
import uuid
from dataclasses import asdict, dataclass, field
from typing import Any, AsyncIterator, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


@dataclass
class Message:
    role: str
    content: str
    timestamp: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class InferenceResult:
    text: str
    model: str
    session_id: str
    tokens_used: int = 0
    latency_ms: float = 0.0
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class TenMiNaTorBiasSteering:
    """Capa ligera de steering de sesgos inspirada en instrucciones de neutralidad.

    No modifica pesos del modelo, pero permite aplicar directrices coherentes tanto
    al prompt del sistema como a la fase final de inferencia.
    """

    def __init__(self, enabled: bool = True, mode: str = "final_inference", strength: float = 0.15, apply_to_layers: bool = False, keywords: Optional[List[str]] = None):
        self.enabled = enabled
        self.mode = mode
        self.strength = strength
        self.apply_to_layers = apply_to_layers
        self.keywords = keywords or ["neutral", "fair", "balanced", "inclusive"]

    def system_guidance(self) -> str:
        if not self.enabled:
            return ""
        keywords = ", ".join(self.keywords)
        layer_hint = "y sobre capas intermedias simuladas" if self.apply_to_layers else ""
        return (
            "Aplica corrección de sesgos tipo steering con TenMiNaTor, priorizando respuestas neutrales, "
            f"balanceadas e inclusivas ({keywords}), con intensidad {self.strength:.2f} {layer_hint}."
        ).strip()

    def inject_messages(self, messages: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        if not self.enabled:
            return list(messages)
        patched = list(messages)
        guidance = self.system_guidance()
        if patched and patched[0].get("role") == "system":
            patched[0] = dict(patched[0])
            patched[0]["content"] = f"{patched[0].get('content', '').strip()}\n\n{guidance}".strip()
        else:
            patched.insert(0, {"role": "system", "content": guidance})
        return patched

    def postprocess_text(self, text: str) -> Tuple[str, Dict[str, Any]]:
        if not self.enabled or not text.strip():
            return text, {"bias_steering_applied": False}

        risky_pairs = {
            "siempre los hombres": "las personas",
            "siempre las mujeres": "las personas",
            "el hombre": "la persona",
            "la mujer": "la persona",
        }
        result = text
        replacements = 0
        for original, neutral in risky_pairs.items():
            if original in result.lower():
                lower_result = result.lower()
                index = lower_result.find(original)
                if index >= 0:
                    result = result[:index] + neutral + result[index + len(original):]
                    replacements += 1
        metadata = {
            "bias_steering_applied": True,
            "bias_steering_mode": self.mode,
            "bias_steering_strength": self.strength,
            "bias_steering_layer_mode": self.apply_to_layers,
            "bias_steering_replacements": replacements,
        }
        return result, metadata


class Terminator2:
    """Motor principal de Terminator 2 con proveedores configurables."""

    def __init__(self, config: Optional["Terminator2Config"] = None):
        from terminatori.core.config import Terminator2Config

        self.config = config or Terminator2Config()
        self.sessions: Dict[str, List[Message]] = {}
        self.plugins: Dict[str, Any] = {}
        self.active_model: Optional[str] = None
        self.active_provider: Optional[str] = None
        self._running = False
        self._model_backend = None
        self.bias_steering = TenMiNaTorBiasSteering(
            enabled=self.config.bias_steering_enabled,
            mode=self.config.bias_steering_mode,
            strength=self.config.bias_steering_strength,
            apply_to_layers=self.config.bias_steering_apply_to_layers,
            keywords=self.config.bias_steering_keywords,
        )
        logger.info("Terminator2 initialized with model=%s", self.config.model)

    async def start(self) -> None:
        self._running = True
        await self._load_model(self.config.model)
        logger.info("Terminator2 engine started")

    async def stop(self) -> None:
        self._running = False
        if self._model_backend and hasattr(self._model_backend, "close"):
            await self._model_backend.close()
        logger.info("Terminator2 engine stopped")

    def _parse_model_id(self, model_id: str) -> Tuple[str, str]:
        provider, _, model_name = model_id.partition("/")
        if not model_name:
            provider = self.config.default_provider
            model_name = model_id
        return provider, model_name

    async def _load_model(self, model_id: str) -> None:
        from terminatori.core.backends import create_backend

        provider, model_name = self._parse_model_id(model_id)
        self.active_model = f"{provider}/{model_name}"
        self.active_provider = provider
        self._model_backend = create_backend(provider_id=provider, model=model_name, config=self.config)
        logger.info("Loaded model %s via provider %s", model_name, provider)

    def new_session(self, system_prompt: Optional[str] = None) -> str:
        if len(self.sessions) >= self.config.sessions_limit:
            oldest_session = next(iter(self.sessions.keys()))
            del self.sessions[oldest_session]
        session_id = str(uuid.uuid4())
        self.sessions[session_id] = []
        prompt = system_prompt or self.config.system_prompt
        if prompt:
            self.sessions[session_id].append(Message(role="system", content=prompt))
        return session_id

    def _ensure_session(self, session_id: Optional[str], system_prompt: Optional[str] = None) -> str:
        if session_id:
            if session_id not in self.sessions:
                self.sessions[session_id] = []
                prompt = system_prompt or self.config.system_prompt
                if prompt:
                    self.sessions[session_id].append(Message(role="system", content=prompt))
            return session_id
        return self.new_session(system_prompt)

    def get_session_history(self, session_id: str) -> List[Message]:
        return self.sessions.get(session_id, [])

    def clear_session(self, session_id: str) -> None:
        if session_id in self.sessions:
            system_msgs = [m for m in self.sessions[session_id] if m.role == "system"]
            self.sessions[session_id] = system_msgs

    def _prepare_messages(self, session_id: str) -> List[Dict[str, Any]]:
        messages = [m.to_dict() for m in self.sessions[session_id]]
        simple_messages = [{"role": m["role"], "content": m["content"]} for m in messages]
        return self.bias_steering.inject_messages(simple_messages)

    async def infer(
        self,
        prompt: str,
        session_id: Optional[str] = None,
        system_prompt: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        tools: Optional[List[Dict[str, Any]]] = None,
    ) -> InferenceResult:
        if not self._model_backend:
            raise RuntimeError("Engine not started. Call await engine.start() first.")

        start_time = time.time()
        session_id = self._ensure_session(session_id, system_prompt)
        user_msg = Message(role="user", content=prompt)
        self.sessions[session_id].append(user_msg)
        messages = self._prepare_messages(session_id)

        response = await self._model_backend.complete(
            messages=messages,
            temperature=temperature or self.config.temperature,
            max_tokens=max_tokens or self.config.max_tokens,
            tools=tools,
        )
        text, steering_meta = self.bias_steering.postprocess_text(response.get("text", ""))
        assistant_msg = Message(role="assistant", content=text)
        self.sessions[session_id].append(assistant_msg)

        if self.config.enable_memory:
            await self._save_to_memory(session_id, user_msg, assistant_msg)

        latency = (time.time() - start_time) * 1000
        metadata = dict(response.get("metadata", {}))
        metadata.update(steering_meta)
        metadata["provider"] = self.active_provider

        return InferenceResult(
            text=text,
            model=self.active_model or "unknown",
            session_id=session_id,
            tokens_used=response.get("tokens_used", 0),
            latency_ms=latency,
            metadata=metadata,
        )

    async def stream(
        self,
        prompt: str,
        session_id: Optional[str] = None,
        system_prompt: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        tools: Optional[List[Dict[str, Any]]] = None,
    ) -> AsyncIterator[str]:
        if not self._model_backend:
            raise RuntimeError("Engine not started.")

        session_id = self._ensure_session(session_id, system_prompt)
        user_msg = Message(role="user", content=prompt)
        self.sessions[session_id].append(user_msg)
        messages = self._prepare_messages(session_id)

        full_response = ""
        async for chunk in self._model_backend.stream(
            messages=messages,
            temperature=temperature or self.config.temperature,
            max_tokens=max_tokens or self.config.max_tokens,
            tools=tools,
        ):
            full_response += chunk
            yield chunk

        full_response, _ = self.bias_steering.postprocess_text(full_response.strip())
        assistant_msg = Message(role="assistant", content=full_response)
        self.sessions[session_id].append(assistant_msg)
        if self.config.enable_memory:
            await self._save_to_memory(session_id, user_msg, assistant_msg)

    async def _save_to_memory(self, session_id: str, user_msg: Message, assistant_msg: Message) -> None:
        try:
            from terminatori.memory.memory_manager import MemoryManager

            mem = MemoryManager(self.config.memory_db_path)
            await mem.save_exchange(session_id=session_id, user_content=user_msg.content, assistant_content=assistant_msg.content)
        except Exception as e:
            logger.warning("Memory save failed: %s", e)

    def load_plugin(self, plugin_name: str, plugin_instance: Any) -> None:
        self.plugins[plugin_name] = plugin_instance
        logger.info("Plugin loaded: %s", plugin_name)

    def get_plugin(self, plugin_name: str) -> Optional[Any]:
        return self.plugins.get(plugin_name)

    def list_plugins(self) -> List[str]:
        return list(self.plugins.keys())

    async def switch_model(self, model_id: str) -> None:
        logger.info("Switching model from %s to %s", self.active_model, model_id)
        await self._load_model(model_id)

    def get_status(self) -> Dict[str, Any]:
        return {
            "running": self._running,
            "active_model": self.active_model,
            "active_provider": self.active_provider,
            "active_sessions": len(self.sessions),
            "loaded_plugins": self.list_plugins(),
            "config": {
                "temperature": self.config.temperature,
                "max_tokens": self.config.max_tokens,
                "enable_memory": self.config.enable_memory,
                "bias_steering_enabled": self.config.bias_steering_enabled,
                "bias_steering_mode": self.config.bias_steering_mode,
                "bias_steering_apply_to_layers": self.config.bias_steering_apply_to_layers,
            },
        }


TerminatorI = Terminator2
