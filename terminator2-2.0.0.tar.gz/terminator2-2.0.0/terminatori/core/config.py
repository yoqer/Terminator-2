"""Configuración principal de Terminator 2."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Dict, List, Optional


@dataclass
class Terminator2Config:
    """Configuración productiva y portable para Terminator 2."""

    model: str = os.getenv("TERMINATOR2_MODEL", os.getenv("TERMINATORI_MODEL", "openai/gpt-4o-mini"))
    default_provider: str = os.getenv("TERMINATOR2_DEFAULT_PROVIDER", "openai")
    provider_timeout: float = float(os.getenv("TERMINATOR2_PROVIDER_TIMEOUT", "60"))
    api_host: str = os.getenv("HOST", os.getenv("TERMINATOR2_HOST", os.getenv("TERMINATORI_HOST", "0.0.0.0")))
    api_port: int = int(os.getenv("PORT", os.getenv("TERMINATOR2_PORT", os.getenv("TERMINATORI_PORT", "8000"))))

    system_prompt: str = os.getenv(
        "TERMINATOR2_SYSTEM_PROMPT",
        os.getenv(
            "TERMINATORI_SYSTEM_PROMPT",
            "Eres Terminator 2, un motor de inferencia productivo, preciso y configurable.",
        ),
    )
    temperature: float = float(os.getenv("TERMINATOR2_TEMPERATURE", os.getenv("TERMINATORI_TEMPERATURE", "0.7")))
    max_tokens: int = int(os.getenv("TERMINATOR2_MAX_TOKENS", os.getenv("TERMINATORI_MAX_TOKENS", "1024")))
    context_length: int = int(os.getenv("TERMINATOR2_CONTEXT_LENGTH", os.getenv("TERMINATORI_CONTEXT_LENGTH", "8192")))
    gpu_layers: int = int(os.getenv("TERMINATOR2_GPU_LAYERS", os.getenv("TERMINATORI_GPU_LAYERS", "0")))

    enable_memory: bool = os.getenv("TERMINATOR2_ENABLE_MEMORY", os.getenv("TERMINATORI_ENABLE_MEMORY", "true")).lower() == "true"
    memory_db_path: str = os.getenv("TERMINATOR2_MEMORY_DB", os.getenv("TERMINATORI_MEMORY_DB", "/tmp/terminator2_memory.db"))
    sessions_limit: int = int(os.getenv("TERMINATOR2_SESSIONS_LIMIT", "200"))

    api_secret: str = os.getenv("TERMINATOR2_API_SECRET", os.getenv("TERMINATORI_API_SECRET", "none"))
    enable_cors: bool = os.getenv("TERMINATOR2_ENABLE_CORS", os.getenv("TERMINATORI_ENABLE_CORS", "true")).lower() == "true"
    cors_origins: List[str] = field(
        default_factory=lambda: [
            origin.strip()
            for origin in os.getenv("TERMINATOR2_CORS_ORIGINS", os.getenv("TERMINATORI_CORS_ORIGINS", "*")).split(",")
            if origin.strip()
        ]
        or ["*"]
    )

    enable_mcp: bool = os.getenv("TERMINATOR2_ENABLE_MCP", os.getenv("TERMINATORI_ENABLE_MCP", "true")).lower() == "true"
    enable_avatar: bool = os.getenv("TERMINATOR2_ENABLE_AVATAR", os.getenv("TERMINATORI_ENABLE_AVATAR", "true")).lower() == "true"
    enable_video: bool = os.getenv("TERMINATOR2_ENABLE_VIDEO", os.getenv("TERMINATORI_ENABLE_VIDEO", "true")).lower() == "true"
    enable_tts: bool = os.getenv("TERMINATOR2_ENABLE_TTS", os.getenv("TERMINATORI_ENABLE_TTS", "true")).lower() == "true"
    enable_stt: bool = os.getenv("TERMINATOR2_ENABLE_STT", os.getenv("TERMINATORI_ENABLE_STT", "true")).lower() == "true"
    enable_robotics: bool = os.getenv("TERMINATOR2_ENABLE_ROBOTICS", os.getenv("TERMINATORI_ENABLE_ROBOTICS", "true")).lower() == "true"

    a2a_agent_name: str = os.getenv("TERMINATOR2_A2A_NAME", os.getenv("TERMINATORI_A2A_NAME", "TERMINATOR2"))
    a2a_agent_description: str = os.getenv(
        "TERMINATOR2_A2A_DESCRIPTION",
        os.getenv(
            "TERMINATORI_A2A_DESCRIPTION",
            "Agente de inferencia multimodal con API HTTP, skills y servicios auxiliares.",
        ),
    )
    skills_dir: str = os.getenv("TERMINATOR2_SKILLS_DIR", os.getenv("TERMINATORI_SKILLS_DIR", "/tmp/terminator2_skills"))

    ollama_url: str = os.getenv("OLLAMA_URL", "http://127.0.0.1:11434")
    openai_api_key: Optional[str] = os.getenv("OPENAI_API_KEY")
    openai_base_url: str = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1")
    xai_api_key: Optional[str] = os.getenv("XAI_API_KEY")
    xai_base_url: str = os.getenv("XAI_BASE_URL", "https://api.x.ai/v1")
    anthropic_api_key: Optional[str] = os.getenv("ANTHROPIC_API_KEY")
    anthropic_base_url: str = os.getenv("ANTHROPIC_BASE_URL", "https://api.anthropic.com/v1")
    deepseek_api_key: Optional[str] = os.getenv("DEEPSEEK_API_KEY")
    deepseek_base_url: str = os.getenv("DEEPSEEK_BASE_URL", "https://api.deepseek.com/v1")
    mistral_api_key: Optional[str] = os.getenv("MISTRAL_API_KEY")
    mistral_base_url: str = os.getenv("MISTRAL_API_BASE", "https://api.mistral.ai/v1")
    openrouter_api_key: Optional[str] = os.getenv("OPENROUTER_API_KEY")
    openrouter_base_url: str = os.getenv("OPENROUTER_BASE_URL", "https://openrouter.ai/api/v1")

    elevenlabs_api_key: Optional[str] = os.getenv("ELEVENLABS_API_KEY")
    fal_api_key: Optional[str] = os.getenv("FAL_KEY") or os.getenv("FAL_API_KEY")
    runway_api_key: Optional[str] = os.getenv("RUNWAY_API_KEY")
    deepgram_api_key: Optional[str] = os.getenv("DEEPGRAM_API_KEY")

    bias_steering_enabled: bool = os.getenv("TERMINATOR2_BIAS_STEERING", "true").lower() == "true"
    bias_steering_mode: str = os.getenv("TERMINATOR2_BIAS_STEERING_MODE", "final_inference")
    bias_steering_strength: float = float(os.getenv("TERMINATOR2_BIAS_STEERING_STRENGTH", "0.15"))
    bias_steering_apply_to_layers: bool = os.getenv("TERMINATOR2_BIAS_STEERING_LAYERS", "false").lower() == "true"
    bias_steering_keywords: List[str] = field(
        default_factory=lambda: [
            item.strip()
            for item in os.getenv(
                "TERMINATOR2_BIAS_STEERING_KEYWORDS",
                "neutral,fair,balanced,non-discriminatory,inclusive",
            ).split(",")
            if item.strip()
        ]
    )

    provider_priority: List[str] = field(
        default_factory=lambda: [
            item.strip()
            for item in os.getenv(
                "TERMINATOR2_PROVIDER_PRIORITY",
                "openai,deepseek,mistral,openrouter,xai,anthropic,ollama,llamacpp",
            ).split(",")
            if item.strip()
        ]
    )
    voice_provider_priority: List[str] = field(
        default_factory=lambda: [
            item.strip()
            for item in os.getenv(
                "TERMINATOR2_VOICE_PROVIDER_PRIORITY",
                "coqui,silero,openai,elevenlabs,kokoro,gtts,grok",
            ).split(",")
            if item.strip()
        ]
    )

    coqui_model_name: str = os.getenv("COQUI_TTS_MODEL", "tts_models/multilingual/multi-dataset/xtts_v2")
    silero_language: str = os.getenv("SILERO_LANGUAGE", "es")
    silero_speaker: str = os.getenv("SILERO_SPEAKER", "random")

    @property
    def provider_credentials(self) -> Dict[str, Dict[str, Optional[str]]]:
        return {
            "openai": {"api_key": self.openai_api_key, "base_url": self.openai_base_url},
            "xai": {"api_key": self.xai_api_key, "base_url": self.xai_base_url},
            "grok": {"api_key": self.xai_api_key, "base_url": self.xai_base_url},
            "anthropic": {"api_key": self.anthropic_api_key, "base_url": self.anthropic_base_url},
            "deepseek": {"api_key": self.deepseek_api_key, "base_url": self.deepseek_base_url},
            "mistral": {"api_key": self.mistral_api_key, "base_url": self.mistral_base_url},
            "openrouter": {"api_key": self.openrouter_api_key, "base_url": self.openrouter_base_url},
            "openai-compatible": {"api_key": self.openai_api_key, "base_url": self.openai_base_url},
            "ollama": {"api_key": None, "base_url": self.ollama_url},
            "llamacpp": {"api_key": None, "base_url": None},
        }


TerminatorIConfig = Terminator2Config
