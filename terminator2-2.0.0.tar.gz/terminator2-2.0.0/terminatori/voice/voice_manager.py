"""Gestor de voz productivo para Terminator 2.

Incluye TTS/STT multi-proveedor con selección configurable desde backend y
compatibilidad con uso local o remoto.
"""

from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class VoiceManager:
    TTS_PROVIDERS = {
        "elevenlabs": "ElevenLabs (alta calidad, API)",
        "grok": "Grok TTS (xAI)",
        "kokoro": "Kokoro TTS local",
        "coqui": "Coqui XTTS / TTS multilingüe",
        "silero": "Silero TTS ligero para CPU/dispositivos pequeños",
        "openai": "OpenAI TTS",
        "gtts": "Google TTS básico",
    }

    STT_PROVIDERS = {
        "whisper": "Whisper API o local",
        "deepgram": "Deepgram API",
        "coqui-stt": "Coqui STT local",
        "silero-stt": "Silero STT local ligero",
    }

    def __init__(self, config=None):
        self.config = config
        self.elevenlabs_key = getattr(config, "elevenlabs_api_key", None) or os.environ.get("ELEVENLABS_API_KEY")
        self.openai_key = getattr(config, "openai_api_key", None) or os.environ.get("OPENAI_API_KEY")
        self.xai_key = getattr(config, "xai_api_key", None) or os.environ.get("XAI_API_KEY")
        self.deepgram_key = getattr(config, "deepgram_api_key", None) or os.environ.get("DEEPGRAM_API_KEY")
        self.audio_dir = Path("~/.terminator2/audio").expanduser()
        self.audio_dir.mkdir(parents=True, exist_ok=True)
        self.coqui_model_name = getattr(config, "coqui_model_name", "tts_models/multilingual/multi-dataset/xtts_v2")
        self.silero_language = getattr(config, "silero_language", "es")
        self.silero_speaker = getattr(config, "silero_speaker", "random")

    async def synthesize(
        self,
        text: str,
        provider: str = "coqui",
        voice_id: Optional[str] = None,
        language: str = "es",
        speed: float = 1.0,
        output_path: Optional[str] = None,
    ) -> Dict[str, Any]:
        generators = {
            "elevenlabs": self._tts_elevenlabs,
            "openai": self._tts_openai,
            "grok": self._tts_grok,
            "kokoro": self._tts_kokoro,
            "coqui": self._tts_coqui,
            "silero": self._tts_silero,
            "gtts": self._tts_gtts,
        }

        gen_fn = generators.get(provider)
        if not gen_fn:
            return {"error": f"Unknown TTS provider: {provider}", "available": list(self.TTS_PROVIDERS.keys())}

        if not output_path:
            import hashlib

            text_hash = hashlib.md5(text.encode()).hexdigest()[:8]
            extension = "wav" if provider in {"coqui", "silero", "kokoro"} else "mp3"
            output_path = str(self.audio_dir / f"tts_{provider}_{text_hash}.{extension}")

        return await gen_fn(text=text, voice_id=voice_id, language=language, speed=speed, output_path=output_path)

    async def _tts_elevenlabs(self, text: str, voice_id=None, language="es", speed=1.0, output_path=None) -> Dict[str, Any]:
        if not self.elevenlabs_key:
            return {"error": "ELEVENLABS_API_KEY not configured", "docs": "https://elevenlabs.io/docs/api-reference"}

        default_voices = {"es": "pNInz6obpgDQGcFmaJgB", "en": "21m00Tcm4TlvDq8ikWAM", "fr": "MF3mGyEYCl7XYWbV9V6O"}
        vid = voice_id or default_voices.get(language, default_voices["en"])
        try:
            import httpx

            headers = {"xi-api-key": self.elevenlabs_key, "Content-Type": "application/json", "Accept": "audio/mpeg"}
            payload = {
                "text": text,
                "model_id": "eleven_multilingual_v2",
                "voice_settings": {"stability": 0.5, "similarity_boost": 0.75, "speed": speed},
            }
            async with httpx.AsyncClient(timeout=60.0) as client:
                resp = await client.post(f"https://api.elevenlabs.io/v1/text-to-speech/{vid}", headers=headers, json=payload)
                resp.raise_for_status()
                Path(output_path).write_bytes(resp.content)
            return {"success": True, "audio_path": output_path, "provider": "elevenlabs", "voice_id": vid, "model": "eleven_multilingual_v2"}
        except Exception as e:
            return {"error": str(e)}

    async def _tts_openai(self, text: str, voice_id=None, language="es", speed=1.0, output_path=None) -> Dict[str, Any]:
        if not self.openai_key:
            return {"error": "OPENAI_API_KEY not configured"}
        voice = voice_id or "nova"
        try:
            import httpx

            headers = {"Authorization": f"Bearer {self.openai_key}", "Content-Type": "application/json"}
            payload = {"model": "tts-1-hd", "input": text, "voice": voice, "speed": max(0.25, min(4.0, speed))}
            async with httpx.AsyncClient(timeout=60.0) as client:
                resp = await client.post("https://api.openai.com/v1/audio/speech", headers=headers, json=payload)
                resp.raise_for_status()
                Path(output_path).write_bytes(resp.content)
            return {"success": True, "audio_path": output_path, "provider": "openai", "voice": voice, "model": "tts-1-hd"}
        except Exception as e:
            return {"error": str(e)}

    async def _tts_grok(self, text: str, voice_id=None, language="es", speed=1.0, output_path=None) -> Dict[str, Any]:
        if not self.xai_key:
            return {"error": "XAI_API_KEY not configured", "docs": "https://docs.x.ai/docs/guides/audio"}
        try:
            import base64
            import httpx

            headers = {"Authorization": f"Bearer {self.xai_key}", "Content-Type": "application/json"}
            payload = {
                "model": "grok-2-audio",
                "messages": [{"role": "user", "content": [{"type": "text", "text": f"Say: {text}"}]}],
                "modalities": ["audio"],
                "audio": {"voice": voice_id or "aria", "format": "mp3"},
            }
            async with httpx.AsyncClient(timeout=60.0) as client:
                resp = await client.post("https://api.x.ai/v1/chat/completions", headers=headers, json=payload)
                resp.raise_for_status()
                data = resp.json()
            audio_b64 = data["choices"][0]["message"].get("audio", {}).get("data")
            if not audio_b64:
                return {"error": "No audio in Grok response", "raw": data}
            Path(output_path).write_bytes(base64.b64decode(audio_b64))
            return {"success": True, "audio_path": output_path, "provider": "grok", "model": "grok-2-audio"}
        except Exception as e:
            return {"error": str(e)}

    async def _tts_kokoro(self, text: str, voice_id=None, language="es", speed=1.0, output_path=None) -> Dict[str, Any]:
        try:
            from kokoro_onnx import Kokoro
            import soundfile as sf

            kokoro = Kokoro("kokoro-v1.0.onnx", "voices-v1.0.bin")
            voice = voice_id or ("af_bella" if language == "en" else "es_maria")
            samples, sample_rate = kokoro.create(text, voice=voice, speed=speed, lang=language)
            sf.write(output_path, samples, sample_rate)
            return {"success": True, "audio_path": output_path, "provider": "kokoro", "voice": voice, "sample_rate": sample_rate}
        except ImportError:
            return {"error": "Kokoro not installed", "install": "pip install kokoro-onnx soundfile"}
        except Exception as e:
            return {"error": str(e)}

    async def _tts_coqui(self, text: str, voice_id=None, language="es", speed=1.0, output_path=None) -> Dict[str, Any]:
        try:
            from TTS.api import TTS

            tts = TTS(model_name=self.coqui_model_name, progress_bar=False)
            speaker_wav = voice_id if voice_id and Path(str(voice_id)).exists() else None
            kwargs: Dict[str, Any] = {"text": text, "file_path": output_path}
            if speaker_wav:
                kwargs["speaker_wav"] = speaker_wav
            if language:
                kwargs["language"] = language
            tts.tts_to_file(**kwargs)
            return {
                "success": True,
                "audio_path": output_path,
                "provider": "coqui",
                "model": self.coqui_model_name,
                "language": language,
                "supports_arabic": True,
                "supports_voice_cloning": speaker_wav is not None,
            }
        except ImportError:
            return {"error": "Coqui TTS not installed", "install": "pip install TTS"}
        except Exception as e:
            return {"error": str(e)}

    async def _tts_silero(self, text: str, voice_id=None, language="es", speed=1.0, output_path=None) -> Dict[str, Any]:
        try:
            import torch
            import soundfile as sf

            lang = language or self.silero_language
            speaker = voice_id or self.silero_speaker
            model, example_text = None, None
            model, _ = torch.hub.load(repo_or_dir="snakers4/silero-models", model="silero_tts", language=lang, speaker="v3_es")
            sample_rate = 48000
            audio = model.apply_tts(text=text, speaker=speaker if speaker != "random" else "aidar", sample_rate=sample_rate)
            sf.write(output_path, audio, sample_rate)
            return {
                "success": True,
                "audio_path": output_path,
                "provider": "silero",
                "language": lang,
                "speaker": speaker,
                "optimized_for_small_devices": True,
            }
        except ImportError:
            return {"error": "Silero dependencies not installed", "install": "pip install torch soundfile"}
        except Exception as e:
            return {"error": str(e)}

    async def _tts_gtts(self, text: str, voice_id=None, language="es", speed=1.0, output_path=None) -> Dict[str, Any]:
        try:
            from gtts import gTTS

            tts = gTTS(text=text, lang=language, slow=(speed < 0.8))
            tts.save(output_path)
            return {"success": True, "audio_path": output_path, "provider": "gtts", "language": language}
        except ImportError:
            return {"error": "gTTS not installed", "install": "pip install gtts"}
        except Exception as e:
            return {"error": str(e)}

    async def transcribe(self, audio_path: str, provider: str = "whisper", language: Optional[str] = None) -> Dict[str, Any]:
        if provider == "whisper":
            return await self._stt_whisper(audio_path, language)
        if provider == "deepgram":
            return await self._stt_deepgram(audio_path, language)
        if provider == "coqui-stt":
            return await self._stt_coqui(audio_path, language)
        if provider == "silero-stt":
            return await self._stt_silero(audio_path, language)
        return {"error": f"Unknown STT provider: {provider}", "available": list(self.STT_PROVIDERS.keys())}

    async def _stt_whisper(self, audio_path: str, language=None) -> Dict[str, Any]:
        if self.openai_key:
            try:
                import httpx

                headers = {"Authorization": f"Bearer {self.openai_key}"}
                with open(audio_path, "rb") as f:
                    files = {"file": (Path(audio_path).name, f, "audio/mpeg")}
                    data = {"model": "whisper-1"}
                    if language:
                        data["language"] = language
                    async with httpx.AsyncClient(timeout=120.0) as client:
                        resp = await client.post("https://api.openai.com/v1/audio/transcriptions", headers=headers, files=files, data=data)
                        resp.raise_for_status()
                        result = resp.json()
                        return {"success": True, "text": result.get("text"), "provider": "whisper-api"}
            except Exception as e:
                return {"error": str(e)}
        try:
            import whisper

            model = whisper.load_model("base")
            result = model.transcribe(audio_path, language=language)
            return {"success": True, "text": result["text"], "language": result.get("language"), "segments": result.get("segments", []), "provider": "whisper-local"}
        except ImportError:
            return {"error": "Whisper not installed and no OPENAI_API_KEY", "install": "pip install openai-whisper"}
        except Exception as e:
            return {"error": str(e)}

    async def _stt_deepgram(self, audio_path: str, language=None) -> Dict[str, Any]:
        if not self.deepgram_key:
            return {"error": "DEEPGRAM_API_KEY not configured"}
        try:
            import httpx

            headers = {"Authorization": f"Token {self.deepgram_key}", "Content-Type": "audio/mpeg"}
            params = {"model": "nova-3", "smart_format": "true"}
            if language:
                params["language"] = language
            with open(audio_path, "rb") as f:
                audio_data = f.read()
            async with httpx.AsyncClient(timeout=120.0) as client:
                resp = await client.post("https://api.deepgram.com/v1/listen", headers=headers, params=params, content=audio_data)
                resp.raise_for_status()
                data = resp.json()
            transcript = data.get("results", {}).get("channels", [{}])[0].get("alternatives", [{}])[0].get("transcript", "")
            return {"success": True, "text": transcript, "provider": "deepgram", "model": "nova-3"}
        except Exception as e:
            return {"error": str(e)}

    async def _stt_coqui(self, audio_path: str, language=None) -> Dict[str, Any]:
        try:
            import wave
            import numpy as np
            from stt import Model

            model_path = os.environ.get("COQUI_STT_MODEL")
            if not model_path:
                return {"error": "COQUI_STT_MODEL not configured", "install": "Configure a Coqui STT model path"}
            model = Model(model_path)
            with wave.open(audio_path, "rb") as wav_file:
                frames = wav_file.readframes(wav_file.getnframes())
                audio = np.frombuffer(frames, np.int16)
            text = model.stt(audio)
            return {"success": True, "text": text, "provider": "coqui-stt", "language": language}
        except ImportError:
            return {"error": "Coqui STT not installed", "install": "pip install coqui-stt numpy"}
        except Exception as e:
            return {"error": str(e)}

    async def _stt_silero(self, audio_path: str, language=None) -> Dict[str, Any]:
        return {
            "error": "Silero STT requires project-specific model packaging",
            "provider": "silero-stt",
            "note": "Reserved for small-device deployments with bundled Torch models.",
            "recommended_languages": ["en", "de", "es"],
        }

    def list_providers(self) -> List[Dict[str, Any]]:
        providers: List[Dict[str, Any]] = []
        for pid, name in self.TTS_PROVIDERS.items():
            providers.append(
                {
                    "id": pid,
                    "name": name,
                    "type": "tts",
                    "configured": self._is_tts_configured(pid),
                    "languages": self._provider_languages(pid),
                }
            )
        for pid, name in self.STT_PROVIDERS.items():
            providers.append(
                {
                    "id": pid,
                    "name": name,
                    "type": "stt",
                    "configured": self._is_stt_configured(pid),
                    "languages": self._provider_languages(pid),
                }
            )
        return providers

    def _provider_languages(self, provider: str) -> List[str]:
        mapping = {
            "coqui": ["ar", "es", "en", "fr", "de", "ru", "zh", "ko", "tr", "pt", "it", "nl", "pl", "cs", "ja", "hu", "hi"],
            "coqui-stt": ["model-dependent"],
            "silero": ["en", "ru", "de", "fr", "es", "uk", "hi"],
            "silero-stt": ["en", "de", "es"],
            "kokoro": ["es", "en"],
            "elevenlabs": ["multilingual"],
            "openai": ["multilingual"],
            "grok": ["multilingual"],
            "gtts": ["google-supported"],
            "whisper": ["multilingual"],
            "deepgram": ["multilingual"],
        }
        return mapping.get(provider, [])

    def _is_tts_configured(self, provider: str) -> bool:
        keys = {
            "elevenlabs": bool(self.elevenlabs_key),
            "openai": bool(self.openai_key),
            "grok": bool(self.xai_key),
            "kokoro": True,
            "coqui": True,
            "silero": True,
            "gtts": True,
        }
        return bool(keys.get(provider, False))

    def _is_stt_configured(self, provider: str) -> bool:
        keys = {
            "whisper": True,
            "deepgram": bool(self.deepgram_key),
            "coqui-stt": True,
            "silero-stt": True,
        }
        return bool(keys.get(provider, False))
