"""CLI de Terminator 2."""

from __future__ import annotations

import asyncio
import json
from typing import Optional

import typer

from terminatori import Terminator2, Terminator2Config
from terminatori.api.app import main as server_main

app = typer.Typer(help="CLI de Terminator 2")


@app.command()
def serve() -> None:
    """Inicia el servidor FastAPI/ASGI."""
    server_main()


@app.command()
def infer(
    prompt: str,
    model: Optional[str] = typer.Option(None, help="Modelo a usar, por ejemplo openai/gpt-4o-mini"),
    temperature: Optional[float] = typer.Option(None, help="Temperatura de inferencia"),
) -> None:
    """Ejecuta una inferencia simple desde terminal."""

    async def _run() -> None:
        cfg = Terminator2Config()
        if model:
            cfg.model = model
        if temperature is not None:
            cfg.temperature = temperature
        engine = Terminator2(cfg)
        await engine.start()
        try:
            result = await engine.infer(prompt)
            typer.echo(json.dumps(result.to_dict(), ensure_ascii=False, indent=2))
        finally:
            await engine.stop()

    asyncio.run(_run())


@app.command("providers")
def providers() -> None:
    """Muestra el catálogo de proveedores configurables."""
    cfg = Terminator2Config()
    typer.echo(json.dumps(cfg.provider_credentials, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    app()
