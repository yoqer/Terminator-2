"""Terminator 2 - motor de inferencia extensible y listo para producción.

El nombre del paquete Python interno se mantiene por compatibilidad, pero la
identidad pública del proyecto para distribución y documentación es Terminator 2.
"""

__version__ = "2.0.0"
__author__ = "yoqer"
__license__ = "MIT"
__description__ = "Terminator 2 production-ready AI inference system with backend providers and TenMiNaTor steering"

try:
    from terminatori.core.engine import Terminator2, TerminatorI
    from terminatori.core.config import Terminator2Config, TerminatorIConfig

    TerminatoriEngine = Terminator2
    TerminatoriConfig = Terminator2Config

    __all__ = [
        "Terminator2",
        "Terminator2Config",
        "TerminatorI",
        "TerminatorIConfig",
        "TerminatoriEngine",
        "TerminatoriConfig",
        "__version__",
    ]
except ImportError:
    __all__ = ["__version__"]
