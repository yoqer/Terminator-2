"""Sistema ligero de skills/Aureolas para TERMINATORI.

Esta implementación prioriza compatibilidad con la suite de pruebas, uso local
sin dependencias externas y una base extensible para futuras integraciones.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional


class BaseSkill:
    """Clase base compatible con skills declaradas por atributos o por init."""

    name = "BaseSkill"
    description = "Base skill"
    category = "general"

    def __init__(
        self,
        name: Optional[str] = None,
        description: Optional[str] = None,
        category: Optional[str] = None,
    ):
        if name is not None:
            self.name = name
        if description is not None:
            self.description = description
        if category is not None:
            self.category = category

    async def execute(self, input_data: str, **kwargs):
        return {"skill": self.name, "input": input_data, "message": self.description}


class AOrAlIASkill(BaseSkill):
    def __init__(self):
        super().__init__(
            name="AOrAlIA",
            description="Reformula y devuelve el contenido de entrada.",
            category="AUREAS",
        )

    async def execute(self, input_data: str, **kwargs):
        return f"AOrAlIA procesó: {input_data}"


class AureAlIASkill(BaseSkill):
    def __init__(self):
        super().__init__(
            name="AureAlIA",
            description="Verificación básica y alineación textual.",
            category="AUREAS",
        )

    async def execute(self, input_data: str, **kwargs):
        return {"aligned": True, "verified": False, "text": input_data}


class IQuestLoopSkill(BaseSkill):
    def __init__(self):
        super().__init__(
            name="IQuestLoop",
            description="Razonamiento iterativo multi-paso simplificado.",
            category="AUREAS",
        )

    async def execute(self, input_data: str, **kwargs):
        return {
            "iterations": 2,
            "input": input_data,
            "result": f"IQuestLoop analizó: {input_data}",
        }


class ErrorInterpretarSkill(BaseSkill):
    def __init__(self):
        super().__init__(
            name="ErrorInterpretar",
            description="Corrección básica de errores de interpretación.",
            category="Razonamiento",
        )

    async def execute(self, input_data: str, **kwargs):
        return {"corrected": input_data.strip(), "status": "reviewed"}


class Synthetic2Skill(BaseSkill):
    def __init__(self):
        super().__init__(
            name="Synthetic2",
            description="Generación simple de estructura sintética.",
            category="Razonamiento",
        )

    async def execute(self, input_data: str, **kwargs):
        return {"seed_text": input_data, "synthetic_variants": [input_data, input_data.upper()]}


class MediapediaSkill(BaseSkill):
    def __init__(self):
        super().__init__(
            name="Mediapedia",
            description="Devuelve una ficha rápida del tema consultado.",
            category="Veridicas",
        )

    async def execute(self, input_data: str, **kwargs):
        return {"topic": input_data, "summary": f"Resumen local disponible para: {input_data}"}


class GenBitSkill(BaseSkill):
    def __init__(self):
        super().__init__(
            name="GenBit",
            description="Detección ligera de sesgos de género por referencias textuales.",
            category="Sesgos",
        )

    async def execute(self, input_data: str, **kwargs):
        lowered = input_data.lower()
        male_terms = ["hombre", "él", "ingeniero", "padre", "chico"]
        female_terms = ["mujer", "ella", "ingeniera", "madre", "chica"]
        male_refs = sum(lowered.count(term) for term in male_terms)
        female_refs = sum(lowered.count(term) for term in female_terms)
        total = male_refs + female_refs
        bias_score = 0.0 if total == 0 else round((male_refs - female_refs) / total, 3)
        return {
            "bias_score": bias_score,
            "male_references": male_refs,
            "female_references": female_refs,
            "text": input_data,
        }


class SafeguardSkill(BaseSkill):
    def __init__(self):
        super().__init__(
            name="Safeguard",
            description="Chequeo simple de seguridad de texto.",
            category="Seguridad",
        )

    async def execute(self, input_data: str, **kwargs):
        lowered = input_data.lower()
        risk_terms = ["arma", "armas", "explosivo", "malware", "hackear"]
        unsafe = any(term in lowered for term in risk_terms)
        return {
            "is_safe": not unsafe,
            "risk_level": "low" if not unsafe else "high",
            "input": input_data,
        }


class AardwarkSkill(BaseSkill):
    def __init__(self):
        super().__init__(
            name="Aardwark",
            description="Moderación local básica por patrones de riesgo.",
            category="Seguridad",
        )

    async def execute(self, input_data: str, **kwargs):
        flags = [term for term in ["violencia", "odio", "malware"] if term in input_data.lower()]
        return {"flagged": bool(flags), "flags": flags}


class MemoryBridgeSkill(BaseSkill):
    def __init__(self):
        super().__init__(
            name="MemoryBridge",
            description="Skill auxiliar para preparar contexto de memoria.",
            category="Memoria",
        )

    async def execute(self, input_data: str, **kwargs):
        return {"context_key": input_data[:32], "stored": False}


class BiasSteeringSkill(BaseSkill):
    def __init__(self):
        super().__init__(
            name="BiasSteering",
            description="Placeholder de corrección de sesgos aplicable a capas o inferencia final.",
            category="Sesgos",
        )

    async def execute(self, input_data: str, **kwargs):
        mode = kwargs.get("mode", "final_inference")
        return {"enabled": True, "mode": mode, "input": input_data}


class PipelineAuditSkill(BaseSkill):
    def __init__(self):
        super().__init__(
            name="PipelineAudit",
            description="Inspección resumida de pipelines locales.",
            category="Operaciones",
        )

    async def execute(self, input_data: str, **kwargs):
        return {"pipeline": input_data, "status": "ok", "steps": len(input_data.split())}


class SkillsManager:
    def __init__(self, skills_dir: Optional[str] = None):
        self.skills_dir = skills_dir
        self._registry: Dict[str, BaseSkill] = {}
        for skill in [
            AOrAlIASkill(),
            AureAlIASkill(),
            IQuestLoopSkill(),
            ErrorInterpretarSkill(),
            Synthetic2Skill(),
            MediapediaSkill(),
            GenBitSkill(),
            SafeguardSkill(),
            AardwarkSkill(),
            MemoryBridgeSkill(),
            BiasSteeringSkill(),
            PipelineAuditSkill(),
        ]:
            self.register(skill)

    def register(self, skill: BaseSkill) -> None:
        self._registry[skill.name] = skill

    def get(self, name: str) -> Optional[BaseSkill]:
        return self._registry.get(name)

    def list_all(self) -> List[Dict[str, Any]]:
        return [
            {"name": skill.name, "description": skill.description, "category": skill.category}
            for skill in self._registry.values()
        ]

    def list_by_category(self) -> Dict[str, List[Dict[str, Any]]]:
        grouped: Dict[str, List[Dict[str, Any]]] = {}
        for item in self.list_all():
            grouped.setdefault(item["category"], []).append(item)
        return grouped

    async def execute(self, name: str, input_data: str, **kwargs):
        skill = self.get(name)
        if not skill:
            return {"error": f"Skill not found: {name}"}
        return await skill.execute(input_data, **kwargs)

    async def execute_pipeline(self, pipeline: List[str], input_data: str):
        steps = []
        current = input_data
        for name in pipeline:
            result = await self.execute(name, current)
            steps.append({"skill": name, "result": result})
            if isinstance(result, str):
                current = result
            elif isinstance(result, dict) and "text" in result and isinstance(result["text"], str):
                current = result["text"]
        return {"pipeline": pipeline, "original_input": input_data, "steps": steps}
