"""Gestor ligero de vídeo para despliegue estándar."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional


class VideoManager:
    def __init__(self, config=None):
        self.config = config
        self.output_dir = Path("./data/videos")
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.runway_key = getattr(config, "runway_api_key", None) if config else None

    def list_providers(self) -> List[Dict[str, Any]]:
        return [
            {"id": "runway", "name": "Runway", "configured": bool(self.runway_key), "requires_key": True},
            {"id": "svd", "name": "Stable Video Diffusion", "configured": False, "requires_key": False},
            {"id": "fal", "name": "fal.ai", "configured": False, "requires_key": True},
            {"id": "minimax", "name": "MiniMax", "configured": False, "requires_key": True},
            {"id": "luma", "name": "Luma", "configured": False, "requires_key": True},
        ]

    async def generate(
        self,
        prompt: Optional[str] = None,
        image_url: Optional[str] = None,
        duration: int = 5,
        provider: str = "runway",
    ) -> Dict[str, Any]:
        providers = {item["id"]: item for item in self.list_providers()}
        if provider not in providers:
            return {"error": f"Unknown provider: {provider}", "available": list(providers.keys())}
        if not prompt and not image_url:
            return {"error": "prompt or image_url is required"}
        if provider == "runway" and not self.runway_key:
            return {
                "error": "runway_api_key is required for real video generation",
                "provider": provider,
            }

        target = self.output_dir / f"video_{provider}_{duration}s.txt"
        target.write_text(f"prompt={prompt}\nimage_url={image_url}\nduration={duration}\nprovider={provider}\n")
        return {
            "success": True,
            "provider": provider,
            "duration": duration,
            "output_path": str(target),
            "note": "Salida local lista para integrarse con proveedor real.",
        }
